import cv2
import numpy as np
from matplotlib import pyplot as plt
import numpy as np
gems = [('White_gem.jpg', 'white', 0.8), ('Blue_gem.jpg', 'blue', 0.8), ('Purple_gem.jpg', 'purple', 0.8), ('Yellow_gem.jpg', 'yellow', 0.8), ('Red_gem.jpg', 'red', 0.8), ('Orange_gem.jpg', 'orange', 0.8), ('Green_gem.jpg', 'green', 0.82)]
general_lst = []

img_rgb = cv2.imread('Jewels.png')
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
for gem in gems:

    template = cv2.imread(gem[0],0)
    w, h = template.shape[::-1]
    print(w, h)
    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = gem[2]
    loc = np.where( res >= threshold)
    lst = []

    for pt in zip(*loc[::-1]):
        lst.append(pt)
       # cv2.rectangle(img_rgb, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)
       
    def sorter(lst, color):
        new_lst = []
        lst = sorted(lst, key=lambda x: x[0])
        #print(lst)
        for object in range(len(lst) - 1):
            if abs(lst[object][0] - lst[object + 1][0]) > 10 or abs(lst[object][1] - lst[object + 1][1]) > 10:
                new_lst.append(lst[object])
        new_lst.append(lst[-1])
       # print(new_lst)
                
        new_lst = sorted(new_lst, key=lambda x: x[1])
        lst = []
        for object in range(len(new_lst) - 1):
            if abs(new_lst[object][0] - new_lst[object + 1][0]) > 10 or abs(new_lst[object][1] - new_lst[object + 1][1]) > 10:
                lst.append((color ,new_lst[object]))
        lst.append((color ,new_lst[-1]))
        #print(lst)
        return lst
    general_lst.append(sorter(lst, gem[1]))
    #def matrix_(lst):
      #  mx = np.matrix(lst)
     #   return mx
    #print(matrix_(sorter(lst)))
        
    for object in sorter(lst, gem[1]):     
        cv2.rectangle(img_rgb, object[1], (object[1][0] + w, object[1][1] + h), (0,0,255), 2)
    cv2.imwrite(gem[0][:-4] + '.png',img_rgb)
gem_lst = []
for tup in general_lst:
    for pair in tup:
        gem_lst.append(pair)
print(gem_lst)