import cv2
import numpy as np
from matplotlib import pyplot as plt
import numpy as np
gems = [('White_gem.jpg', 'white', 0.8), ('Blue_gem.jpg', 'blue', 0.8), ('Purple_gem.jpg', 'purple', 0.8), ('Yellow_gem.jpg', 'yellow', 0.8), ('Red_gem.jpg', 'red', 0.8), ('Orange_gem.jpg', 'orange', 0.8), ('Green_gem.jpg', 'green', 0.82), ('Green_flame.jpg', 'green_flame', 0.8)]
general_lst = []

img_rgb = cv2.imread('Jewels.png')
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

def mx(lst):
    
    return np.array(lst, dtype=object)
        
def new_sort(lst, color):
    new_lst = []
    #new_lst = sorted(lst, key=lambda x: x[0])
    for i in range(len(lst)):
        is_duplicate = False
        for j in range(len(new_lst)):
            if abs(lst[i][0] - new_lst[j][1][0]) < 10 and abs(lst[i][1] - new_lst[j][1][1]) < 10:
                is_duplicate = True
        if not is_duplicate:
            new_lst.append((color,lst[i]))
    new_lst.sort(key=lambda x: x[1][0])    
    return new_lst
          
            
    
for gem in gems:
    template = cv2.imread(gem[0],0)
    w, h = template.shape[::-1]
    print(w, h)
    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = gem[2]
    loc = np.where(res >= threshold)
    lst = []
    
    for pt in zip(*loc[::-1]):
        lst.append(pt)
    general_lst += (new_sort(lst, gem[1]))
        
    for i in new_sort(lst, gem[1]):     
        cv2.rectangle(img_rgb, i[1], (i[1][0] + w, i[1][1] + h), (0,0,255), 2)
    cv2.imwrite(gem[0][:-4] + '.png',img_rgb)

general_lst.sort(key=lambda x: x[1][1])
mat_lst = []

print(len(general_lst))
for i in range(0,len(general_lst) - 7, 8):
    part = general_lst[i:i + 8]
    part.sort(key=lambda x: x[1][0])
    mat_lst += part
#print(general_lst[:8])
print(mat_lst)
print(mx(mat_lst))
